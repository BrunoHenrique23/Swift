//
//  QuestaoViewController.swift
//  iQuiz
//
//  Created by Bruno Henrique Ferraz da Silva on 10/11/24.
//

import UIKit

class QuestaoViewController: UIViewController {
    
    var pontuacao: Int = 0
    var numeroQuestao: Int = 0

    @IBOutlet weak var lblTitulo: UILabel!
    
    @IBOutlet var bototesRespostas: [UIButton]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configurarLayout()
        configurarQuestao()
    }
    
    @IBAction func respostaBotaoPressionado(_ sender: UIButton) {
        let acerto = questoes[numeroQuestao].respostaCerta == sender.tag
        
        if acerto {
                pontuacao += 1
            sender.backgroundColor = UIColor.corDeFundoVerde
        } else {
            sender.backgroundColor = UIColor.corDeFundoVermelho
        }
        if(numeroQuestao < questoes.count - 1){
            numeroQuestao += 1
            Timer.scheduledTimer(timeInterval: 2, target: self, selector: #selector(configurarQuestao), userInfo: nil, repeats: false)
        }else{
            navegaParaTelaDesempenho()
        }
    }
    
    func navegaParaTelaDesempenho() {
        performSegue(withIdentifier: "irParaTelaDesempenho", sender: nil)
    }
    
    func configurarLayout() {
        navigationItem.hidesBackButton = true
        lblTitulo.numberOfLines = 0
        lblTitulo.textAlignment = .center
        for botao in bototesRespostas {
            botao.layer.cornerRadius = 15
        }

    }
    
    @objc func configurarQuestao() {
         lblTitulo.text = questoes[numeroQuestao].titulo
         for botao in bototesRespostas {
             let titulo = questoes[numeroQuestao].respostas[botao.tag]
             botao.setTitle(titulo, for: .normal)
             
             botao.backgroundColor = UIColor(red: 116/255, green: 50/255, blue: 255/255, alpha: 1)
         }
     }
    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
       guard let desempenhoVC = segue.destination as? DesempenhoViewController else { return }
        desempenhoVC.pontuacao = pontuacao
        desempenhoVC.numeroQuestao = numeroQuestao
        
    }
    

}
