//
//  Questao.swift
//  iQuiz
//
//  Created by Bruno Henrique Ferraz da Silva on 10/11/24.
//

import Foundation

struct Questao{
    
    var titulo: String
    
    var respostas: [String]
    
    var respostaCerta: Int
    
}

let questoes: [Questao] = [
    Questao(titulo: "Qual o feitiço para desarmar o seu oponente em Harry Potter?", respostas: ["Expecto Patronum", "Expelliarmus", "Expulso"], respostaCerta: 1),
    Questao(titulo: "Quando foi lançado o filme Vingadores Ultimato?", respostas: ["2019","2018","2017"], respostaCerta: 2),
    Questao(titulo: "Quando foi lançado o filme Avatar 2?", respostas: ["2014","2022","2023"], respostaCerta: 1),
    
    Questao(titulo: "Qual é o primeiro filme da franquia Star Wars?", respostas: ["Star Wars: A Ameaça Fantasma","Star Wars: O Retorno do Jedi","Star Wars: O Primeiro Encounter"], respostaCerta: 1)
]
